package com.meritamerica.assignment7.exceptions;

public class ExceedsFraudSuspicionLimitException extends Exception {
	
	public ExceedsFraudSuspicionLimitException() {
        super("ExceedsFraudSuspicionLimitException");
    }
}
