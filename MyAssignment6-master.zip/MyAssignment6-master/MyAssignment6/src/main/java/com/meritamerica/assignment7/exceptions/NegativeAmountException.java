package com.meritamerica.assignment7.exceptions;

public class NegativeAmountException extends Exception {
	public NegativeAmountException() {
        super("NegativeAmountException");
    }
}
