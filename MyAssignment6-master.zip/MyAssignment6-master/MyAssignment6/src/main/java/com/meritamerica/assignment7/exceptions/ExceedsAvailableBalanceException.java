package com.meritamerica.assignment7.exceptions;

public class ExceedsAvailableBalanceException extends Exception {
	public ExceedsAvailableBalanceException() {
        super("ExceedsAvailableBalanceException");
    }
}
