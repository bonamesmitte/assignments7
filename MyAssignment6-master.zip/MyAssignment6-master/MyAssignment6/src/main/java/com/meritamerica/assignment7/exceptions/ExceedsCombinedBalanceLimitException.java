package com.meritamerica.assignment7.exceptions;

public class ExceedsCombinedBalanceLimitException extends Exception {
	public ExceedsCombinedBalanceLimitException() {
        super("ExceedsCombinedBalanceLimitException");
    }
}
